const products = [
  {
    id: "P001",
    name: "Luxury Kurta",
    quality: "Premium",
    fabric: "Cotton",
    price: "৳1200",
    description: "সুন্দর ডিজাইনের সাদা কুর্তা।",
    image: "https://via.placeholder.com/300x400",
  },
  {
    id: "P002",
    name: "Elegant Saree",
    quality: "High Quality",
    fabric: "Silk",
    price: "৳2500",
    description: "মসৃণ ও আরামদায়ক সিল্ক শাড়ি।",
    image: "https://via.placeholder.com/300x400",
  },
];

export default products;
